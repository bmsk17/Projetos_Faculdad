Arquivo zip gerado em: 11/10/2018 20:57:39 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Star Trek