#include <iostream>
#include <locale>
#include <string>
#include <math.h>

using namespace std;

class Soldado {

private:

    string Nome;              //Não coloquei typedef só porque pra mim fica mais fácil de escrever a função depois;
    string Raca;
    int Forca,i,j;

public:

    Soldado (){}
    Soldado (string Nome,string Raca,int i,int j, int Forca){   //Padrao da forma que será dado na entrada;
         this->Nome = Nome;
         this->Raca = Raca;
         this->i = i;
         this->j = j;
         this->Forca = Forca;
    }

    void setNome(string Nome);
    string getNome();
    void setRaca (string Raca);
    string getRaca();
    void setI(int i);
    int getI();
    void setJ(int j);
    int getJ();
    void setForca(int Forca);
    int getForca();
    void ImprimeSoldado();
};


void Soldado::setNome(string Nome){
      this->Nome = Nome;
}

string Soldado::getNome(){
     return this->Nome;
}

void Soldado::setRaca(string Raca){
     this->Raca = Raca;
}

string Soldado::getRaca(){
    return this->Raca;
}

void Soldado::setI(int i){
     this->i = i;

}

int Soldado::getI(){

   return this->i;

}

void Soldado::setJ(int j){
     this->i = i;

}

int Soldado::getJ(){

   return this->j;

}

void Soldado::setForca(int Forca){

   this->Forca = Forca;
}

int Soldado::getForca(){
return this->Forca;
}


void Soldado::ImprimeSoldado(){

  cout <<"Nome: "<<Nome <<" " << "Raca: "<<Raca << " "<<"Forca: "<<Forca << " "<<"Posicao: "<<i<<" "<<j<<"\n";

}

// IMPLEMENTANDO A CLASSE NO ENCAPSULADA

class No {

private:

    Soldado soldado;
    No* prox;

public:

    No (){            //CONSTRUTOR PADRAO

    prox = NULL;

    }

    No (Soldado soldado){

       this->soldado = soldado;
       prox = NULL;
    }

    No* getProx (){         //RETORNA PONTEIRO PARA O PROXIMO NO
      return this->prox;
    }

    void setNULL (){        //ANULA O PONTEIRO PARA O NO SEGUINTE AO ULTIMO JA QUE ELE NAO EXISTE

      this->prox = NULL;
    }

    void setSoldado (Soldado soldado){   // INSERE O SOLDADO NA VARIAVEL SOLDADO DESSA CLASSE

      this->soldado = soldado;
    }

    Soldado getSoldado (){      //RETORNA O SOLDADO QUE ESTA NESSA CLASSE

      return this->soldado;

    }

   void setNo (){            //CRIA UM NOVO NO VISTO QUE ESTÁ ENCAPSULADO E É PRECISO FAZER "MANUALMENTE"

     this->prox = new No ();

    }

};

//IMPLEMENTANDO A CLASSE LISTA

class Lista_Soldados {

private:

    No *prim, *ult;
    int TAM;             // UTIL PARA INFORMAR O TAMANHO ATUAL DA LISTA

public:

    Lista_Soldados (){

      prim = new No ();
      prim->setNULL();
      ult = prim;
      TAM = 0;
    }


     void Insere (Soldado soldado);
     void Imprime_Lista();
     No* getPrim();
};

No* Lista_Soldados::getPrim(){

   return prim;
}

void Lista_Soldados::Insere(Soldado soldado){

    ult->setNo();             //CRIANDO NOVO NO
    ult = ult->getProx();
    ult->setNULL();
    ult->setSoldado(soldado);
    TAM++;

}

void Lista_Soldados::Imprime_Lista(){

  No* p = prim->getProx();   //PEGA O PRIMEIRO NO DEPOIS DO CABEÇA

  while (p != NULL){

    p->getSoldado().ImprimeSoldado();
    p = p->getProx();

  }
}

//IMPLEMENTANDO A CLASSE TABELA HASH


class TabelaHash {

public:

  Lista_Soldados thash[43];


  void InsereHash(string Nome,string Raca,Soldado soldado);
  int FuncaoHash(string Chave);
  int RecuperaForca(string Chave);
  void ImprimeHash(int Pos);


};

void TabelaHash::InsereHash(string Nome,string Raca,Soldado soldado){  //Insere na tabela após fazer os procedimentos padrões de escolha de posição

    int aux;
    string Chave;


    Chave = Nome+Raca;

    aux = FuncaoHash(Chave);

    thash[aux].Insere(soldado);

}

int TabelaHash::FuncaoHash(string Chave){      //Converter o nome+raça pra minúsculo, e depois, retorna um número inteiro para o indice do vetor hash.

   int Soma = 0;
   int p;
   locale loc;

   p = Chave.length();

for (unsigned int i=0; i<Chave.length(); ++i){
    Chave[i] = tolower(Chave[i],loc);
    Soma = Soma+ (((unsigned char)Chave[i]) * pow(31,p));
    p--;
}

 return Soma%43;

}

int TabelaHash::RecuperaForca(string Chave){   //Recupera a força de todos que estão na posição que tu quiser ver


    int aux;
    int soma=0;
    No* p;



    aux = FuncaoHash(Chave);
    p = thash[aux].getPrim()->getProx();


    while (p != NULL){

        soma = soma + p->getSoldado().getForca();
        p = p->getProx();

    }

    return soma;


}

void TabelaHash::ImprimeHash(int Pos){ //Apenas fiz pra testar se estava sendo inserido corretamente na tabela

  thash[Pos].Imprime_Lista();

}


int main (){

  TabelaHash l;
  int i,j;

  Soldado a ("A31","AZURI",3,1,40);
  Soldado b ("A22","AZURI",2,2,45);

  l.InsereHash("A31","AZURI",a); //Hash desse troço é 8
  l.InsereHash("A22","AZURI",b); //Hash desse troço tbm é 8

  i = l.RecuperaForca("A31AZURI"); //Recupera a força da posição onde esse cara tá, como os 2 que eu inseri tem o mesmo hash vai retornar a soma de a+b

  l.ImprimeHash(8);

cout <<"Soma das forças da tabela na pos 8 "<< i; //deu certo carai!!


return 0;

}















