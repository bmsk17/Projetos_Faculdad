#include <iostream>
using namespace std;

class Capturado {

private:

    string Nome;              //PADRÃO DO CAPTURADO
    string Raca;
    int Forca;

public:

    Capturado (){}
    Capturado (string Nome,string Raca,int Forca){   //REMOVI O INDICADOR DE POSIÇÃO VISTO QUE OS CAPTURADOS NÃO TEM ESSE VALOR PASSADO POR PARAMETRO. ELES ESTÃO JÁ JUNTO COM O SOLDADO NA SUA PROPRIA POSIÇÃO
         this->Nome = Nome;
         this->Raca = Raca;
         this->Forca = Forca;
    }

    void setNome(string Nome);
    string getNome();
    void setRaca (string Raca);
    string getRaca();
    void setForca(int Forca);
    int getForca();
    void ImprimeCapturado();
};

class Node {                      //ATUALIZADO COM O ENCAPSULAMENTO

private:

    Capturado capturado;
    Node* prox;

public:

    Node(){
    prox = NULL;
    }

    Node (Capturado capturado){
     this->capturado = capturado;
     prox = NULL;
    }

    void setNode();
    Node* getProx ();
    void setNo();
    void setCapturado(Capturado capturado);
    Capturado getCapturado();

};

class Fila {

private:

    Node *tras, *frente;
    int TAM;

public:

    Fila (){  //CRIA A FILA

      frente = new Node ();
      frente->setNode();
      tras = frente;
      TAM=0;

    }

    void InsereCapturado (Capturado capturado);
    void Imprime_Fila();
    void Remove_Capturado();
    int  Forca_dos_Capturados();
};


class Soldado {

private:

    string Nome;
    string Raca;
    int Forca,i,j;
    Fila capturado;

public:

    Soldado (){}
    Soldado (string Nome,string Raca,int i,int j, int Forca,Fila capturado){
         this->Nome = Nome;
         this->Raca = Raca;
         this->i = i;
         this->j = j;
         this->Forca = Forca;
         this->capturado = capturado;
    }

    void setNome(string Nome);
    string getNome();
    void setRaca (string Raca);
    string getRaca();
    void setI(int i);
    int getI();
    void setJ(int j);
    int getJ();
    void setForca(int Forca);
    int getForca();
    void setCapturado(Fila capturado);
    Fila getCapturado();
    void ImprimeSoldado();
    int Forca_Conjunta_Capturados();
    void Soldado_Remove_Capturado();
};


class No_PilhaTropa {
private:
    Soldado soldado;
    No_PilhaTropa* prox;

public:
    No_PilhaTropa() {} // construtor
    Soldado getSoldado() {
        return soldado;
    }

    void setSoldado(Soldado soldado);
    No_PilhaTropa* getProx();
    void setProx(No_PilhaTropa* prox);
};


class Pilha_Tropa {
private:
    No_PilhaTropa *fundo, *topo;
    int tamanho;

public:
    Pilha_Tropa(); // construtor
    void empilha(Soldado soldado);
    bool vazia();
    void desempilha(Soldado soldado);  // AQUI TU TINHA COLOCADO ASSIM ->>void desempilha(Soldado& soldado); <<-- COMO TU JA TA PASSANDO COMO PARAMETRO O soldado (MINUSCULO) N PRECISA COLOCAR O &, TU USA O & APENAS QUANDO NÃO QUER COLOCAR O NOME DA VARIAVEL COMO PARAMETRO!
    void mostra();
    No_PilhaTropa* getTopo(); // botei para poder usar esses ponteiros na classe tabuleiro
    int Forca_Conjunta_Soldados();
    void setTamanho(int Tamanho);
    int getTamanho();
    void Trocar_Posicao(int pfx,int pfy);
    void Ordenar_Pilha();
};


class No {

private:

    Pilha_Tropa Tropa;
    No* prox;

public:

    No (){           //CONSTRUTOR PADRAO
    prox = NULL;
    }

    No (Pilha_Tropa Tropa){
       this->Tropa = Tropa;
       prox = NULL;
    }

    No* getProx ();
    void setNULL ();
    void setTropa (Pilha_Tropa Tropa);
    Pilha_Tropa getTropa ();
    void setNo ();
};


class Lista_Tropa {

private:

    No *prim, *ult;
    int TAM;             // UTIL PARA INFORMAR O TAMANHO ATUAL DA LISTA

public:

    Lista_Tropa (){
      TAM=0;
      prim = new No ();
      prim->setNULL();
      ult = prim;
    }

     No* getPrim(); // botei para poder usar esses ponteiros na classe tabuleiro
     No* getUlt();
     void Insere (Pilha_Tropa Tropa);
     void Imprime_Lista();
};


class Tabuleiro {
// Pra controlar o numnero de quadradinhos nos podemos simplismente na hora do cara inserir fazer um if para nao aceitar valores maiores que 9 e menores que 0
// estava pensando e dava pra fazer as outras funções sem necessidade de criar esta, mas para fins de organizaççao fiz deste jeito
// dentro da pilha_tropa e da lista_tropa botei função get e set para poder fazer a busca logo abaixo
private:
    Lista_Tropa U_tatica; // pega a lista_tropa onde estao armazenados todas as tropas e soldados inseridos

public:

    Tabuleiro (){}
    Tabuleiro (Lista_Tropa U_tatica){   //construtor
         this->U_tatica= U_tatica;
    }
    void setU_tatica(Lista_Tropa U_tatica);
    Lista_Tropa getU_tatica();
    No* busca(int pix,int piy);
    void Mova(int pix,int piy,int pfx,int pfy);
    void Forca_raca(string raca);
    void Forca(int pix,int piy);
    void terr(int pix,int piy);
    int Movimento_Valido(int pix,int piy,int pfx,int pfy);
};
