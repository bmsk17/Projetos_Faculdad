#include "ClassesPP1.hpp"

//---------------------------------------Metodos Capturados ------------------------------------

void Capturado::setNome(string Nome){
      this->Nome = Nome;
}

string Capturado::getNome(){
     return this->Nome;
}

void Capturado::setRaca(string Raca){
     this->Raca = Raca;
}

string Capturado::getRaca(){
    return this->Raca;
}

void Capturado::setForca(int Forca){
   this->Forca = Forca;
}

int Capturado::getForca(){
return this->Forca;
}

void Capturado::ImprimeCapturado(){
  cout <<"Nome: "<<Nome <<" " << "Raca: "<<Raca << " "<<"Forca: "<<Forca<<"\n";
}

//---------------------------------------Metodos Node ------------------------------------

void Node::setNode(){
  this->prox = NULL;   //ANULA O PONTEIRO DO ULTIMO NO QUE NÃO EXISTE
}

Node* Node::getProx (){
  return this->prox;   //RETORNA PONTEIRO PARA O PROXIMO NO DA FILA
}

void Node::setNo(){
  this->prox = new Node();  //CRIA NOVO NO PARA INSERIR
}

void Node::setCapturado(Capturado capturado){  //FAZ O QUE O NOME DO METODO DIZ KKK
  this->capturado = capturado;
}

Capturado Node::getCapturado(){      //IDEM
   return this->capturado;
}

//---------------------------------------Metodos FIla ------------------------------------

void Fila::InsereCapturado (Capturado capturado){          //INSERÇÃO ATUALIZADA COM O ENCAPSULAMENTO

   tras->setNo();
   tras = tras->getProx();
   tras->setCapturado(capturado);
   tras->setNode();
   TAM++;
}

void Fila::Imprime_Fila(){             //IMPRESSAO ATUALIZADA COM O ENCAPSULAMENTO
   Node* p = frente->getProx();
   while (p != NULL){
    p->getCapturado().ImprimeCapturado();
    p = p->getProx();
   }
}

void Fila::Remove_Capturado(){   //REMOÇÃO ATUALIZADA COM O ENCAPSULAMENTO
    Node* aux = frente;
    frente = frente->getProx();
    TAM--;
    delete aux;
}

int Fila::Forca_dos_Capturados(){
    Node* p = frente->getProx();
    p = frente->getProx();
    int TOTAL = 0;
    while (p != NULL){
      TOTAL = TOTAL + p->getCapturado().getForca();
      p = p->getProx();
    }
    return TOTAL;
}
//---------------------------------------Metodos Soldado ------------------------------------
void Soldado::setNome(string Nome){
      this->Nome = Nome;
}

string Soldado::getNome(){
     return this->Nome;
}

void Soldado::setRaca(string Raca){
     this->Raca = Raca;
}

string Soldado::getRaca(){
    return this->Raca;
}

void Soldado::setI(int i){
     this->i = i;
}

int Soldado::getI(){
   return this->i;
}

void Soldado::setJ(int j){
     this->i = i;
}

int Soldado::getJ(){
   return this->j;
}

void Soldado::setForca(int Forca){
   this->Forca = Forca;
}

int Soldado::getForca(){
return this->Forca;
}

void Soldado::setCapturado(Fila capturado){
   this->capturado = capturado;
}

Fila Soldado::getCapturado(){
return this->capturado;
}

int Soldado::Forca_Conjunta_Capturados(){
  int TOTAL = 0;
  TOTAL = getForca()+getCapturado().Forca_dos_Capturados();
  return TOTAL;
}
void Soldado::ImprimeSoldado(){
  cout <<"Nome: "<<Nome <<" " << "Raca: "<<Raca << " "<<"Forca: "<<Forca_Conjunta_Capturados() << " "<<"Posicao: "<<i<<" "<<j<<endl;
}
void Soldado::Soldado_Remove_Capturado(){
  Fila f =getCapturado();
  f.Remove_Capturado();
  setCapturado(f);
}

//---------------------------------------Metodos No_PilhaTropa ------------------------------------

void No_PilhaTropa::setSoldado(Soldado soldado) {
  this->soldado = soldado;
}

No_PilhaTropa* No_PilhaTropa::getProx() {
  return prox;
}

void No_PilhaTropa::setProx(No_PilhaTropa* prox) {
  this->prox = prox;
}

//---------------------------------------Metodos Pilha_Tropa ------------------------------------

void Pilha_Tropa::Ordenar_Pilha(){
  for (No_PilhaTropa *nav = topo->getProx(); nav != nullptr;nav = nav->getProx()) {
      No_PilhaTropa *nav2 = nav->getProx();
      int fora1 = nav->getSoldado().Forca_Conjunta_Capturados();
      int fora2 = nav2->getSoldado().Forca_Conjunta_Capturados();
      if(fora2 > fora1){
        Soldado aux = nav->getSoldado();
        Soldado aux2 = nav2->getSoldado();
        nav->setSoldado(aux2);
        nav2->setSoldado(aux);
      }
  }
}
void Pilha_Tropa::setTamanho(int Tamanho){
      this->tamanho = Tamanho;
}

int Pilha_Tropa::getTamanho(){
     return this->tamanho;
}

No_PilhaTropa* Pilha_Tropa::getTopo(){
    return this->topo;
}

Pilha_Tropa::Pilha_Tropa() {
    fundo = new No_PilhaTropa(); // nó cabeça
    topo = fundo;
    tamanho=0;
}

void Pilha_Tropa::empilha(Soldado soldado) {
    No_PilhaTropa *aux = new No_PilhaTropa();
    topo->setSoldado(soldado);
    aux->setProx(topo);
    topo = aux;
    tamanho++;
}

bool Pilha_Tropa::vazia() {
    return topo == fundo;
}

void Pilha_Tropa::desempilha(Soldado soldado) {
    if (vazia()) {
        cout << "pilha vazia: impossível remover item\n";
    }
    else {
        No_PilhaTropa *aux = topo;
        topo = topo->getProx();
        soldado = topo->getSoldado();
        tamanho--;
        delete aux;
    }
}

void Pilha_Tropa::mostra() {
    for (No_PilhaTropa *nav = topo->getProx(); nav != nullptr;nav = nav->getProx()) {
        std::cout << '\n';
        nav->getSoldado().ImprimeSoldado();
        cout<<" Capturados de "<<nav->getSoldado().getNome()<<" : "<<endl;
        nav->getSoldado().getCapturado().Imprime_Fila();
    }
}
int Pilha_Tropa::Forca_Conjunta_Soldados(){
    int TOTAL=0;
    for (No_PilhaTropa *nav = topo->getProx(); nav != nullptr;nav = nav->getProx()) {
        TOTAL = TOTAL + nav->getSoldado().Forca_Conjunta_Capturados();
    }
    return TOTAL;
}
void Pilha_Tropa::Trocar_Posicao(int pfx,int pfy){
  for (No_PilhaTropa *nav = topo->getProx(); nav != nullptr;nav = nav->getProx()) {
      nav->getSoldado().setI(pfx);
      nav->getSoldado().setJ(pfy);
  }
}

//---------------------------------------Metodos No ------------------------------------

No* No::getProx (){         //RETORNA PONTEIRO PARA O PROXIMO NO
  return this->prox;
}

void No::setNULL (){        //ANULA O PONTEIRO PARA O NO SEGUINTE AO ULTIMO JA QUE ELE NAO EXISTE
  this->prox = NULL;
}

void No::setTropa (Pilha_Tropa Tropa){   // INSERE O SOLDADO NA VARIAVEL SOLDADO DESSA CLASSE
  this->Tropa = Tropa;
}

Pilha_Tropa No::getTropa (){      //RETORNA O SOLDADO QUE ESTA NESSA CLASSE
  return this->Tropa;
}

void No::setNo (){            //CRIA UM NOVO NO VISTO QUE EST� ENCAPSULADO E � PRECISO FAZER "MANUALMENTE"
 this->prox = new No ();
}

//---------------------------------------Metodos Lista_Tropa ------------------------------------

No* Lista_Tropa::getPrim(){
     return this->prim;
}
No* Lista_Tropa::getUlt(){
     return this->ult;
}
void Lista_Tropa::Insere(Pilha_Tropa Tropa){

    ult->setNo();             //CRIANDO NOVO NO
    ult = ult->getProx();
    ult->setNULL();
    ult->setTropa(Tropa);
    TAM++;
}

void Lista_Tropa::Imprime_Lista(){

  No* p = prim->getProx();   //PEGA O PRIMEIRO NO DEPOIS DO CABE�A
  while (p != NULL){
    p->getTropa().mostra();
    p = p->getProx();
  }
}

//---------------------------------------Metodos Tabuleiro ------------------------------------

Lista_Tropa Tabuleiro::getU_tatica(){
    return this->U_tatica;
}

void Tabuleiro::setU_tatica(Lista_Tropa U_tatica){
    this->U_tatica = U_tatica;
}

int Tabuleiro::Movimento_Valido(int pix,int piy,int pfx,int pfy){
  if((pfx == pix-3) >= 0 && (pfx == pix+3)<=43){
    if(pfy==piy){
      return 1;
    }else{
      return 0;
    }
  }else if((pfy == piy-3)>=0 && (pfy == piy+3)<=10){
    if(pfx==pix){
      return 1;
    }else{
      return 0;
    }
  }
}

No* Tabuleiro::busca(int pix,int piy){ // pesquisa no soldado (dentro da pilha_tropa dentro da lista_tropa dentro do tabuleiro ) a posição re torna o poteiro da pilha_tropa caso haja alguma tropa nessa posição
    No *p = U_tatica.getPrim()->getProx();
    cout <<"----------------------------- FAzendo Busca  ------"<<endl;
    while (p != NULL){
      Soldado c = p->getTropa().getTopo()->getProx()->getSoldado();
      if(c.getI() == pix && c.getJ() == piy){
        return p;
      }
      p = p->getProx();
    }
    return nullptr;
}
void Tabuleiro::Mova(int pix,int piy,int pfx,int pfy){ //verificar se função busca esta funcionando
  string racaDefensora = "null";
  string racaAtacante = "null";
  No* a = busca(pix,piy);
  No* d = busca(pfx,pfy);
  int x = Movimento_Valido(pix,piy,pfx,pfy);
  if( a != nullptr && x == 1){
    std::cout << a->getTropa().getTopo()->getProx()->getSoldado().getRaca() << '\n';
    racaDefensora = d->getTropa().getTopo()->getProx()->getSoldado().getRaca();
     if(d==nullptr){
          a->getTropa().Trocar_Posicao(pfx,pfy);
       }else if(racaAtacante == racaDefensora){
          for (No_PilhaTropa *nav = a->getTropa().getTopo()->getProx(); nav != nullptr;
                                     nav = nav->getProx()) {
          Soldado s = nav->getSoldado();
          d->getTropa().empilha(s);
      }
  }else if (racaAtacante != racaDefensora){
  }else{
    Soldado c = a->getTropa().getTopo()->getProx()->getSoldado();
    c.ImprimeSoldado();
  }
  }
}
void Tabuleiro::Forca_raca(string raca){
   // procura todos os soldados  de uma Raca
   //e soma suas forcas, talvez tenhamos de mudar la pra frente
   //, mas no mazimo 5 linhas de codigo
    int total=0;
    No *p = U_tatica.getPrim()->getProx();
    cout <<"-----------------------------"<<endl;
    while (p != NULL){
          No_PilhaTropa *nav = p->getTropa().getTopo()->getProx();
          Soldado c = nav->getSoldado();
          if(c.getRaca() == raca){
            total = total + p->getTropa().Forca_Conjunta_Soldados();
          }
      p = p->getProx();
    }
    cout << "TOTAL da raca " << raca << " : " << total<<"!"<<endl;
    cout <<"-----------------------------"<<endl;

}
void Tabuleiro::Forca(int pix,int piy){
  int total=0;
  No* d = busca(pix,piy);
  if(d == nullptr){
    cout << -1 << endl;
  }else{
    cout << d->getTropa().Forca_Conjunta_Soldados() << endl;
}
}
void Tabuleiro::terr(int pix,int piy){
  No* p = busca(pix,piy);
  if(p == nullptr){
    cout<<"[]"<<endl;
  }else{
    int x = p->getTropa().getTamanho();
    No_PilhaTropa *nav = p->getTropa().getTopo()->getProx();
    Soldado c = nav->getSoldado();
    if(x == 1){
      cout<<"[" <<c.getNome()<<" "<<c.getRaca()<<" "<<c.Forca_Conjunta_Capturados()<<"]" <<endl;
    }else{
      cout<<"[[" <<c.getNome()<<" "<<c.getRaca()<<" "<<c.Forca_Conjunta_Capturados()<<"]]" <<endl;

    }
  }
}
