#include "ClassesPP1.hpp"


int main(){

  Fila f;Fila f2;Fila f3;Fila f4;Fila f5;Fila f6;

  Capturado x1 ("A1","bernardo",40);
  Capturado x2 ("B1","kanekiyo",20);
  Capturado x3 ("C3","amanda",10);
  Capturado x4 ("D5","deubson",4);
  Capturado x5 ("D5","deubson",4);

  f.InsereCapturado(x1);f.InsereCapturado(x2);f.InsereCapturado(x3);f.InsereCapturado(x4);
  f2.InsereCapturado(x1);f2.InsereCapturado(x2);f2.InsereCapturado(x3);f2.InsereCapturado(x4);
  f3.InsereCapturado(x1);f3.InsereCapturado(x2);f3.InsereCapturado(x3);f3.InsereCapturado(x4);
  f4.InsereCapturado(x1);f4.InsereCapturado(x2);f4.InsereCapturado(x3);f4.InsereCapturado(x4);
  f5.InsereCapturado(x1);f5.InsereCapturado(x2);f5.InsereCapturado(x3);f5.InsereCapturado(x4);


  Pilha_Tropa p1;     //instancciando pilhas
  Pilha_Tropa p2;
  Pilha_Tropa p3;
  Pilha_Tropa p4;
  Pilha_Tropa p5;

  Soldado a ("A1","AZURI",1,2,40,f);
  Soldado b ("B1","AZURI",1,2,20,f2);
  Soldado c ("C3","AZURI",1,2,10,f3);
  Soldado d ("D5","AZURI",1,2,4,f4);
  Soldado e ("e6","AZURI",1,2,4,f5);       //instancciando soldados
  Soldado y ("dfsad","UMASHI",4,1,10,f);
  Soldado t ("sdgf","UMASHI",4,1,4,f);
  Soldado z ("123","UMASHI",4,1,10,f);
  Soldado x ("345","UMASHI",4,1,4,f);
  Soldado p21 ("123453453453","RATATA",3,1,10,f);
  Soldado p22 ("34345355","RATATA",3,1,4,f);
  Soldado a12 ("345","UMASHI",7,1,4,f);

//  f.Imprime_Fila();
//  a.ImprimeSoldado();
 a.Soldado_Remove_Capturado();f.InsereCapturado(x5);
//  std::cout << endl <<"DEPOIS DE REMOVER" << endl;
//  a.getCapturado().Imprime_Fila();
/*  a.ImprimeSoldado();
  b.ImprimeSoldado();
  c.ImprimeSoldado();
  d.ImprimeSoldado();
  e.ImprimeSoldado();
  y.ImprimeSoldado();
  t.ImprimeSoldado();
  z.ImprimeSoldado();
  x.ImprimeSoldado();
  p21.ImprimeSoldado();
  p22.ImprimeSoldado();
*/
  p1.empilha(y);
  p1.empilha(t);      //INserindo soldados em suas tropas
  p1.empilha(z);      //so pode inserir soldados em uma tropa se tiverem a mesma posição
  p1.empilha(x);
  p2.empilha(p21);
  p2.empilha(p22);
  p3.empilha(a);
  p3.empilha(b);
  p3.empilha(c);
  p3.empilha(d);
  p3.empilha(e);
  p4.empilha(a);
  p4.empilha(b);
  p4.empilha(c);
  p4.empilha(d);
  p4.empilha(e);
  p5.empilha(a12);
// cout <<"IMPRIMINDO A PILHA \n\n";
// p3.mostra();

//  p1.desempilha(a);  //APENAS PRA TESTAR SE OS METODOS TÃO EM ORDEM

 //cout <<"IMPRIMINDO DEPOIS DE REMOVER \n\n";
  //p1.mostra();
  Lista_Tropa lt; //instancciando lista_tropa
  lt.Insere(p3);
  lt.Insere(p1);  //INserindo pilha_tropa na lista_tropa
  lt.Insere(p2);
  lt.Insere(p4);
  lt.Insere(p5);
  Tabuleiro tab (lt); //instancciando Tabuleiro
//  tab.busca(4,1);
//  tab.Mova(1,2,4,2);   //testando funções da classes tabuleiro
  //tab.Forca_raca("AZURI");
//tab.Forca(6,2);
  p3.mostra();
//
  return 0;
}
