//
//  Pilha.h
//  AED1 - Pilhas
//
//  Created by Coelho on 04/04/16.
//  Copyright © 2016 Flavio Jose Mendes Coelho. All rights reserved.
//

#ifndef Pilha_h
#define Pilha_h

#include <iostream>
#include <cstddef>
using namespace std;

// Número
class Item {
private:
    int valor;

public:
    // Construtores
    Item() { }
    Item(int valor): valor(valor) { }

    int getValor() {
        return valor;
    }

    void setValor(int valor) {
        this->valor = valor;
    }

    void mostra() {
        cout << valor << " ";
    }
};

class No {
private:
    Item item;
    No *prox;

public:
    No() {} // construtor

    Item getItem() {
        return item;
    }

    void setItem(Item item) {
        this->item = item;
    }

    No* getProx() {
        return prox;
    }

    void setProx(No* prox) {
        this->prox = prox;
    }
};


class Pilha {
private:
    No *fundo, *topo;

public:
    Pilha(); // construtor
    void empilha(Item);
    bool vazia();
    void desempilha(Item&);
    void mostra();
};


#endif /* Pilha_h */
