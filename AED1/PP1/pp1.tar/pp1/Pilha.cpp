//
//  Pilha.cpp
//  AED1 - Pilhas
//
//  Created by Coelho on 04/04/16.
//  Copyright © 2016 Flavio Jose Mendes Coelho. All rights reserved.
//

#include "Pilha.h"

Pilha::Pilha() {
    fundo = new No(); // nó cabeça
    topo = fundo;
}

void Pilha::empilha(Item item) {
    No *aux = new No();
    topo->setItem(item);
    aux->setProx(topo);
    topo = aux;
}

bool Pilha::vazia() {
    return topo == fundo;
}

void Pilha::desempilha(Item& item) {
    if (vazia()) {
        cout << "pilha vazia: impossível remover item\n";
    }
    else {
        No *aux = topo;
        topo = topo->getProx();
        item = topo->getItem();
        delete aux;
    }
}

void Pilha::mostra() {
    cout << "Pilha: topo-> ";
    for (No *nav = topo->getProx(); nav != nullptr;
                                   nav = nav->getProx()) {
        nav->getItem().mostra();
    }
    cout << "<- fundo\n";
}
