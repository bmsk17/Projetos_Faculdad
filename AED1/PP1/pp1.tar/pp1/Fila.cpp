#include <iostream>

using namespace std;


class Item {

private:
   string Nome_Pessoa;

public:

   Item (){}
   Item (string Nome_Pessoa){
      this->Nome_Pessoa = Nome_Pessoa;
   }

   void setNome_Pessoa(string Nome_Pessoa);
   string getNome_Pessoa();
   void ImprimeItem();

};

void Item::setNome_Pessoa(string Nome_Pessoa){
     this->Nome_Pessoa = Nome_Pessoa;

}

string Item::getNome_Pessoa (){
    return Nome_Pessoa;
}

void Item::ImprimeItem(){

   cout << "NOME: "<< Nome_Pessoa <<"\n";

}


class No {

public:

    Item item;
    No* prox;

    No(){

    prox = NULL;
    }

    No (Item item){

     this->item = item;
     prox = NULL;
    }

};

class Fila {

private:

    No *tras, *frente;
    int TAM;

public:

    Fila (){

      frente = new No ();
      frente->prox = NULL;
      tras = frente;
      TAM=0;

    }

    void InsereItem (Item item);
    void Imprime_Fila();
    void Remove_Item();
};

void Fila::InsereItem (Item item){

   tras->prox = new No();
   tras = tras->prox;
   tras->item = item;
   tras->prox = NULL;
   TAM++;
}

void Fila::Imprime_Fila(){

   No* p = frente->prox;

   while (p != NULL){

    p->item.ImprimeItem();
    p = p->prox;

   }
}

void Fila::Remove_Item(){

    No* aux = frente;

    frente = frente->prox;

    delete aux;

}

int main (){

  Fila f;

  Item a ("Joao");
  Item b ("Pedro");
  Item c ("Tiao");
  Item d ("Maria");

  f.InsereItem(a);
  f.InsereItem(b);
  f.InsereItem(c);
  f.InsereItem(d);


  f.Imprime_Fila();

  f.Remove_Item();

  cout <<"PRIMEIRO ELEMENTO REMOVIDO \n\n";
  f.Imprime_Fila();



  cout << "READICIONANDO O REMOVIDO NA FILA \n\n";
  f.InsereItem(a);
  f.Imprime_Fila();

return 0;

}
