//
//  main.cpp
//  AED1 - Pilhas
//
//  Created by Coelho on 04/04/16.
//  Copyright © 2016 Flavio Jose Mendes Coelho. All rights reserved.
//

#include <iostream>
#include "Pilha.h"

typedef Item Numero;

int main(int argc, const char * argv[]) {
    Pilha p;

    // Povoa a pilha
    Numero it;
    for (int i = 1; i <= 10; ++i) {
        it.setValor(i);
        p.empilha(it);
        p.mostra();
   }

    // Desempilha
    while (!p.vazia()) {
        p.desempilha(it);
        p.mostra();
    }

    std::cout << "\n";
    return 0;
}
